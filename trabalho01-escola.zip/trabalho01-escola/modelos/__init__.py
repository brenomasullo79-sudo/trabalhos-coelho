from .endereco import Endereco
from .aluno import Aluno
from .professor import Professor
from .sala_de_aula import SalaDeAula
from .escola import Escola
