class SalaDeAula:

    def __init__(self, escola, numero, capacidade, bloco="A"):
        # A sala sempre pertence a uma escola, por isso o parametro e obrigatorio.
        # Nao e pra criar SalaDeAula direto, quem cria e a Escola (criar_sala).
        self.escola = escola
        self.numero = numero
        self.capacidade = capacidade
        self.bloco = bloco
        self.tem_projetor = False

    def comporta(self, qtd_alunos):
        return qtd_alunos <= self.capacidade

    def alterar_capacidade(self, nova_capacidade):
        if nova_capacidade <= 0:
            raise ValueError("A capacidade tem que ser maior que zero")
        self.capacidade = nova_capacidade

    def instalar_projetor(self):
        self.tem_projetor = True

    def __str__(self):
        projetor = "com projetor" if self.tem_projetor else "sem projetor"
        return f"Sala {self.numero} (bloco {self.bloco}) - {self.capacidade} lugares, {projetor}"
