class Professor:

    def __init__(self, nome, cpf, disciplina, email=""):
        self.nome = nome
        self.cpf = cpf
        self.disciplina = disciplina
        self.email = email
        # Associacao: lista das escolas onde ele da aula.
        # O professor existe mesmo que essa lista esteja vazia.
        self.escolas = []

    def lecionar_em(self, escola):
        escola.contratar_professor(self)

    def sair_da_escola(self, escola):
        escola.desligar_professor(self)

    def listar_escolas(self):
        return [escola.nome for escola in self.escolas]

    def __str__(self):
        return f"Prof. {self.nome} ({self.disciplina})"
