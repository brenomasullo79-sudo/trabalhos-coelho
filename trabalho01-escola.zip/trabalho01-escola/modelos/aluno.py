from datetime import date


class Aluno:

    def __init__(self, matricula, nome, data_nascimento, endereco):
        self.matricula = matricula
        self.nome = nome
        self.data_nascimento = data_nascimento

        # Agregacao: o aluno so guarda a referencia do endereco.
        # Se o aluno sair do sistema o objeto Endereco continua vivo
        # e pode ser usado em outro lugar (relatorio, por exemplo).
        self.endereco = endereco

    def idade(self):
        hoje = date.today()
        anos = hoje.year - self.data_nascimento.year
        if (hoje.month, hoje.day) < (self.data_nascimento.month, self.data_nascimento.day):
            anos -= 1
        return anos

    def mudar_endereco(self, novo_endereco):
        antigo = self.endereco
        self.endereco = novo_endereco
        return antigo

    def liberar_endereco(self):
        # chamado quando o aluno e removido: devolve o endereco
        # em vez de apagar ele junto
        endereco = self.endereco
        self.endereco = None
        return endereco

    def __str__(self):
        return f"{self.matricula} - {self.nome} ({self.idade()} anos)"
