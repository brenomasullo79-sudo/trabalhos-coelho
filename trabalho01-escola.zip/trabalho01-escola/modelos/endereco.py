class Endereco:

    def __init__(self, rua, numero, bairro, cidade, uf, cep):
        self.rua = rua
        self.numero = numero
        self.bairro = bairro
        self.cidade = cidade
        self.uf = uf
        self.cep = cep

    def atualizar(self, rua=None, numero=None, bairro=None, cidade=None, uf=None, cep=None):
        # so troca o que foi passado, o resto continua igual
        if rua:
            self.rua = rua
        if numero:
            self.numero = numero
        if bairro:
            self.bairro = bairro
        if cidade:
            self.cidade = cidade
        if uf:
            self.uf = uf
        if cep:
            self.cep = cep

    def cep_valido(self):
        digitos = self.cep.replace("-", "").replace(".", "")
        return len(digitos) == 8 and digitos.isdigit()

    def formatado(self):
        return f"{self.rua}, {self.numero} - {self.bairro}, {self.cidade}/{self.uf} - CEP {self.cep}"

    def __str__(self):
        return self.formatado()
