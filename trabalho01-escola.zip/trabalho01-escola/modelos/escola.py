from .sala_de_aula import SalaDeAula


class Escola:

    def __init__(self, nome, codigo_inep, cidade):
        self.nome = nome
        self.codigo_inep = codigo_inep
        self.cidade = cidade
        self.ativa = True

        self._salas = []        # composicao -> as salas sao criadas e destruidas pela escola
        self.professores = []   # associacao -> os professores existem por conta propria

    # --- salas (composicao) ---

    def criar_sala(self, numero, capacidade, bloco="A"):
        if not self.ativa:
            raise RuntimeError("Escola fechada, nao da pra criar sala")
        if self.buscar_sala(numero) is not None:
            raise ValueError(f"Ja existe a sala {numero} em {self.nome}")

        sala = SalaDeAula(self, numero, capacidade, bloco)
        self._salas.append(sala)
        return sala

    def buscar_sala(self, numero):
        for sala in self._salas:
            if sala.numero == numero:
                return sala
        return None

    def remover_sala(self, numero):
        sala = self.buscar_sala(numero)
        if sala is not None:
            self._salas.remove(sala)
            sala.escola = None

    def listar_salas(self):
        # devolve uma copia pra ninguem mexer na lista de fora
        return list(self._salas)

    def capacidade_total(self):
        return sum(sala.capacidade for sala in self._salas)

    # --- professores (associacao) ---

    def contratar_professor(self, professor):
        if professor not in self.professores:
            self.professores.append(professor)
            professor.escolas.append(self)

    def desligar_professor(self, professor):
        if professor in self.professores:
            self.professores.remove(professor)
            professor.escolas.remove(self)

    def listar_professores(self):
        return [str(p) for p in self.professores]

    def fechar(self):
        # as salas deixam de existir junto com a escola
        for sala in self._salas:
            sala.escola = None
        self._salas.clear()

        # os professores so perdem o vinculo, continuam cadastrados
        for professor in list(self.professores):
            self.desligar_professor(professor)

        self.ativa = False

    def __str__(self):
        situacao = "ativa" if self.ativa else "fechada"
        return f"{self.nome} - {self.cidade} (INEP {self.codigo_inep}) [{situacao}]"
