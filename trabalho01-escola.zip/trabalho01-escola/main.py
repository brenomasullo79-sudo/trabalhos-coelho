from datetime import date

from modelos import Escola, Professor, Aluno, Endereco


def titulo(texto):
    print()
    print(texto)
    print("-" * len(texto))


def cadastrar_aluno(matricula, nome, nascimento, rua, numero, bairro, cidade, uf, cep):
    # o endereco e criado no mesmo momento do cadastro do aluno
    endereco = Endereco(rua, numero, bairro, cidade, uf, cep)
    return Aluno(matricula, nome, nascimento, endereco)


def remover_aluno(alunos, aluno, enderecos_relatorio):
    alunos.remove(aluno)
    # o endereco nao some junto, ele e repassado pro relatorio
    enderecos_relatorio.append(aluno.liberar_endereco())


def main():
    # ---------------------------------------------------------------
    titulo("1) Composicao: Escola e SalaDeAula")

    escola1 = Escola("Escola Municipal Raimundo Nonato", "22011234", "Parnaíba")
    escola1.criar_sala(101, 35)
    escola1.criar_sala(102, 30)
    lab = escola1.criar_sala(201, 20, bloco="B")
    lab.instalar_projetor()

    print(escola1)
    for sala in escola1.listar_salas():
        print("  ", sala)
    print("Capacidade total:", escola1.capacidade_total(), "alunos")
    print("A sala 102 comporta 32 alunos?", escola1.buscar_sala(102).comporta(32))

    # ---------------------------------------------------------------
    titulo("2) Associacao: Professor e Escola")

    escola2 = Escola("Unidade Escolar Dom Bosco", "22019876", "Buriti dos Lopes")

    marcos = Professor("Marcos Vinícius", "111.222.333-44", "Matemática")
    lucia = Professor("Lúcia Helena", "555.666.777-88", "Língua Portuguesa")

    # o mesmo professor pode estar em mais de uma escola
    marcos.lecionar_em(escola1)
    marcos.lecionar_em(escola2)
    escola1.contratar_professor(lucia)

    print(f"{escola1.nome}: {escola1.listar_professores()}")
    print(f"{escola2.nome}: {escola2.listar_professores()}")
    print(f"{marcos.nome} leciona em: {marcos.listar_escolas()}")

    # ---------------------------------------------------------------
    titulo("3) Fechando a escola 1")

    escola1.fechar()
    print(escola1)
    print("Salas que sobraram:", len(escola1.listar_salas()))
    print(f"{marcos.nome} continua no sistema e agora leciona em: {marcos.listar_escolas()}")
    print(f"{lucia.nome} continua no sistema, escolas: {lucia.listar_escolas()}")

    # ---------------------------------------------------------------
    titulo("4) Agregacao: Aluno e Endereco")

    alunos = []
    enderecos_relatorio = []

    ana = cadastrar_aluno("2026001", "Ana Beatriz Sousa", date(2010, 3, 15),
                          "Rua São José", "120", "Centro", "Parnaíba", "PI", "64200-000")
    pedro = cadastrar_aluno("2026002", "Pedro Henrique Lima", date(2011, 8, 2),
                            "Av. Getúlio Vargas", "455", "São Benedito", "Parnaíba", "PI", "64202-120")
    alunos.append(ana)
    alunos.append(pedro)

    for aluno in alunos:
        print(aluno, "->", aluno.endereco)

    remover_aluno(alunos, pedro, enderecos_relatorio)
    del pedro

    print()
    print("Alunos depois da remocao:", [a.nome for a in alunos])
    print("Enderecos guardados pro relatorio:")
    for endereco in enderecos_relatorio:
        print("  ", endereco, "| CEP valido:", endereco.cep_valido())


if __name__ == "__main__":
    main()
