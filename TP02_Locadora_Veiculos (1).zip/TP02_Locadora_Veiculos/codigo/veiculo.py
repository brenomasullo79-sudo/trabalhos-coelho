from abc import ABC, abstractmethod


class Veiculo(ABC):
    # classe abstrata: na locadora não existe "veículo genérico",
    # sempre vai ser carro, moto ou caminhão

    def __init__(self, placa, modelo, ano, valor_diaria):
        self.placa = placa.upper()
        self.modelo = modelo
        self.ano = ano
        self.valor_diaria = valor_diaria
        self.disponivel = True

    def calcular_diarias(self, dias):
        return self.valor_diaria * dias

    def reservar(self):
        # é aqui que garantimos que o veículo não fica em dois contratos ativos
        if not self.disponivel:
            raise ValueError(f"O veículo {self.placa} já está em um contrato ativo.")
        self.disponivel = False

    def liberar(self):
        self.disponivel = True

    @abstractmethod
    def categoria_exigida(self):
        pass

    def __str__(self):
        return f"{type(self).__name__} {self.modelo} {self.ano} (placa {self.placa})"


class Carro(Veiculo):
    def __init__(self, placa, modelo, ano, valor_diaria, portas=4, cambio="manual"):
        super().__init__(placa, modelo, ano, valor_diaria)
        self.portas = portas
        self.cambio = cambio

    def categoria_exigida(self):
        return "B"


class Moto(Veiculo):
    TAXA_BAU = 15.0  # por dia

    def __init__(self, placa, modelo, ano, valor_diaria, cilindradas, possui_bau=False):
        super().__init__(placa, modelo, ano, valor_diaria)
        self.cilindradas = cilindradas
        self.possui_bau = possui_bau

    def categoria_exigida(self):
        return "A"

    def calcular_diarias(self, dias):
        valor = super().calcular_diarias(dias)
        if self.possui_bau:
            valor += self.TAXA_BAU * dias
        return valor
