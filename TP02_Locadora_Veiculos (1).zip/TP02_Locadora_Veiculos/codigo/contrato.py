from datetime import date


class Condutor:
    def __init__(self, nome, numero_cnh, categoria, validade_cnh):
        self.nome = nome
        self.numero_cnh = numero_cnh
        self.categoria = categoria.upper()
        self.validade_cnh = validade_cnh

    def cnh_valida(self, na_data=None):
        if na_data is None:
            na_data = date.today()
        return self.validade_cnh >= na_data

    def pode_dirigir(self, veiculo):
        exigida = veiculo.categoria_exigida()
        if exigida == "A":
            return "A" in self.categoria
        # de B até E quem tem a categoria "maior" também dirige as de baixo
        # (ex.: CNH D pode dirigir carro)
        ordem = "BCDE"
        return any(letra in ordem and ordem.index(letra) >= ordem.index(exigida)
                   for letra in self.categoria)

    def __str__(self):
        return f"{self.nome} - CNH {self.numero_cnh} (cat. {self.categoria})"


class ContratoLocacao:
    ATIVO = "ativo"
    FINALIZADO = "finalizado"
    CANCELADO = "cancelado"

    _ultimo_numero = 0

    def __init__(self, cliente, veiculo, data_inicio, data_termino_prevista,
                 dados_condutor):
        if data_termino_prevista <= data_inicio:
            raise ValueError("A data de término tem que ser depois do início.")

        # COMPOSIÇÃO: o contrato recebe só os dados e cria o condutor aqui dentro.
        # Nenhuma outra parte do sistema guarda esse objeto, então quando o
        # contrato deixa de existir o condutor vai junto.
        condutor = Condutor(**dados_condutor)

        if not condutor.cnh_valida(data_inicio):
            raise ValueError(f"A CNH de {condutor.nome} está vencida.")
        if not condutor.pode_dirigir(veiculo):
            raise ValueError(
                f"{condutor.nome} não tem a categoria {veiculo.categoria_exigida()} "
                f"exigida para {veiculo.modelo}."
            )

        # só reserva depois de validar o condutor, senão o veículo ficaria
        # preso num contrato que nem chegou a ser criado
        veiculo.reservar()

        ContratoLocacao._ultimo_numero += 1
        self.numero = ContratoLocacao._ultimo_numero
        self.cliente = cliente
        self.veiculo = veiculo
        self.data_inicio = data_inicio
        self.data_termino_prevista = data_termino_prevista
        self.data_devolucao = None
        self.status = self.ATIVO
        self._condutor = condutor
        self.valor_total = self.calcular_valor_total()

    @property
    def condutor(self):
        # só leitura: não tem como trocar o condutor por fora do contrato
        return self._condutor

    def quantidade_dias(self, data_fim=None):
        fim = data_fim or self.data_termino_prevista
        return (fim - self.data_inicio).days

    def calcular_valor_total(self, data_fim=None):
        return self.veiculo.calcular_diarias(self.quantidade_dias(data_fim))

    def esta_ativo(self):
        return self.status == self.ATIVO

    def finalizar(self, data_devolucao):
        if not self.esta_ativo():
            raise ValueError(f"Contrato {self.numero} não está ativo.")
        # se devolveu antes ou depois do previsto, cobra pelos dias reais
        self.data_devolucao = data_devolucao
        self.valor_total = self.calcular_valor_total(data_devolucao)
        self.status = self.FINALIZADO
        self.veiculo.liberar()

    def cancelar(self):
        if not self.esta_ativo():
            raise ValueError(f"Contrato {self.numero} não está ativo.")
        self.status = self.CANCELADO
        self.valor_total = 0
        self.veiculo.liberar()

    def resumo(self):
        inicio = self.data_inicio.strftime("%d/%m/%Y")
        fim = self.data_termino_prevista.strftime("%d/%m/%Y")
        linhas = [
            f"Contrato nº {self.numero} [{self.status}]",
            f"  Cliente:  {self.cliente}",
            f"  Veículo:  {self.veiculo}",
            f"  Condutor: {self.condutor}",
            f"  Período:  {inicio} a {fim} ({self.quantidade_dias()} dias)",
        ]
        if self.data_devolucao:
            linhas.append(
                f"  Devolvido em {self.data_devolucao:%d/%m/%Y}"
                f" ({self.quantidade_dias(self.data_devolucao)} dias)"
            )
        linhas.append(f"  Valor:    {formatar_reais(self.valor_total)}")
        return "\n".join(linhas)


def formatar_reais(valor):
    texto = f"{valor:,.2f}"
    return "R$ " + texto.replace(",", "X").replace(".", ",").replace("X", ".")
