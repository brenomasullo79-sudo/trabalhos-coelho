import weakref
from datetime import date

from cliente import PessoaFisica, PessoaJuridica
from contrato import ContratoLocacao
from veiculo import Carro, Moto


maria = PessoaFisica("Maria do Carmo Silva", "123.456.789-00", "(86) 99812-4471")
empresa = PessoaJuridica("Delta Transportes LTDA", "12.345.678/0001-90", "(86) 3321-5560",
                         nome_fantasia="Delta")

onix = Carro("PIA1B23", "Chevrolet Onix", 2023, 120.00, cambio="automático")
cg = Moto("PIB4C56", "Honda CG 160", 2024, 70.00, cilindradas=160, possui_bau=True)


print("--- Teste 1: abrindo um contrato ---")
c1 = ContratoLocacao(
    maria, onix, date(2026, 10, 1), date(2026, 10, 6),
    dados_condutor={
        "nome": "Maria do Carmo Silva",
        "numero_cnh": "04518823907",
        "categoria": "B",
        "validade_cnh": date(2029, 3, 15),
    },
)
print(c1.resumo())


print("\n--- Teste 2: alugando o mesmo carro com o contrato 1 ainda ativo ---")
try:
    ContratoLocacao(
        empresa, onix, date(2026, 10, 3), date(2026, 10, 5),
        dados_condutor={
            "nome": "José Ribamar Sousa",
            "numero_cnh": "07733190245",
            "categoria": "D",
            "validade_cnh": date(2027, 8, 1),
        },
    )
except ValueError as erro:
    print("Não deixou:", erro)


print("\n--- Teste 3: condutor só com categoria B tentando alugar moto ---")
try:
    ContratoLocacao(
        maria, cg, date(2026, 10, 2), date(2026, 10, 4),
        dados_condutor={
            "nome": "Maria do Carmo Silva",
            "numero_cnh": "04518823907",
            "categoria": "B",
            "validade_cnh": date(2029, 3, 15),
        },
    )
except ValueError as erro:
    print("Não deixou:", erro)

print("Mesma moto, agora com o filho dela (categoria AB) como condutor:")
c_moto = ContratoLocacao(
    maria, cg, date(2026, 10, 2), date(2026, 10, 5),
    dados_condutor={
        "nome": "Pedro Henrique Silva",
        "numero_cnh": "09912004518",
        "categoria": "AB",
        "validade_cnh": date(2030, 1, 20),
    },
)
print(c_moto.resumo())  # 3 dias x (70 + 15 do baú)


print("\n--- Teste 4: devolvendo o Onix um dia depois do previsto ---")
c1.finalizar(date(2026, 10, 7))
print(c1.resumo())
print("Onix disponível de novo?", onix.disponivel)


print("\n--- Teste 5: agora a empresa consegue alugar o Onix ---")
c2 = ContratoLocacao(
    empresa, onix, date(2026, 10, 8), date(2026, 10, 10),
    dados_condutor={
        "nome": "José Ribamar Sousa",
        "numero_cnh": "07733190245",
        "categoria": "D",
        "validade_cnh": date(2027, 8, 1),
    },
)
print(c2.resumo())


print("\n--- Teste 6: composição (excluindo o contrato o condutor vai junto) ---")
# weakref "observa" o objeto sem segurar ele na memória
condutor_observado = weakref.ref(c2.condutor)
print("Antes de excluir o contrato:", condutor_observado())

c2.cancelar()   # libera o carro
del c2          # exclui o contrato

print("Depois de excluir o contrato:", condutor_observado())
print("Onix disponível?", onix.disponivel)
