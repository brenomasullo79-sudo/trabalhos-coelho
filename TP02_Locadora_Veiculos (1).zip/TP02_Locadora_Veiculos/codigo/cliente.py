from abc import ABC, abstractmethod


class Cliente(ABC):
    # também abstrata: o cliente sempre é PF ou PJ

    def __init__(self, nome, documento, telefone):
        self.nome = nome  # nome da pessoa ou razão social da empresa
        self.documento = documento
        self.telefone = telefone

    def atualizar_telefone(self, novo_telefone):
        self.telefone = novo_telefone

    def _so_numeros(self):
        return "".join(c for c in self.documento if c.isdigit())

    @abstractmethod
    def documento_valido(self):
        pass

    def __str__(self):
        return f"{self.nome} ({self.documento})"


class PessoaFisica(Cliente):
    def documento_valido(self):
        # só confere a quantidade de dígitos do CPF, não calcula os verificadores
        return len(self._so_numeros()) == 11


class PessoaJuridica(Cliente):
    def __init__(self, razao_social, cnpj, telefone, nome_fantasia=None):
        super().__init__(razao_social, cnpj, telefone)
        self.nome_fantasia = nome_fantasia

    def documento_valido(self):
        return len(self._so_numeros()) == 14
